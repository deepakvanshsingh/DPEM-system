﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DPEMS.Exceptions
{
    public class DPEMS_Exceptions:ApplicationException
    {
        public DPEMS_Exceptions(string name) : base(name)
            {

        }

    }
}

