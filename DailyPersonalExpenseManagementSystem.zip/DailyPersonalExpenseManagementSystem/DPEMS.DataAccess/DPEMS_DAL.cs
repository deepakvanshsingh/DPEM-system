﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DPEMS.Entity;
using DPEMS.Exceptions;
using System.IO;
using System.Runtime.Serialization;
using System.Runtime.Serialization.Formatters.Binary;

namespace DPEMS.DataAccess
{
    
    public class DPEMS_DAL
    {
        public static List<BudgetEntity> budgets = new List<BudgetEntity>();
        public static List<ExpenseEntity> expenses = new List<ExpenseEntity>();
        /************************************** Seralizing Budget Data **************************************************/
        public static void BudgetListSerializer(BudgetEntity budget)
        {
            string path = @"C:\Users\Deepak\Desktop\notes\Work from home\DailyPersonalExpenseManagementSystem\DPEMS.DataAccess\DataBase\Budget.txt";
            BinaryFormatter formatter = new BinaryFormatter();
            try
            {


                if (File.Exists(path))
                {
                    budgets = BudgetListDeSerializer();

                    budgets.Add(budget);
                    Stream stream = File.Open(path, FileMode.Open, FileAccess.Write);
                    formatter.Serialize(stream, budgets);
                    stream.Close();
                }
                else
                {
                    budgets.Add(budget);
                    Stream stream = File.Open(path, FileMode.Create, FileAccess.Write);
                    formatter.Serialize(stream, budgets);
                    stream.Close();
                } 
            }
            catch (FileNotFoundException)
            {
                Console.WriteLine("ERROR: File Not Exixt In Current Context!!:");
            }
            catch (Exception fileException)
            {
                Console.WriteLine(fileException.Message);
            }
        }


        /************************************** Seralizing Expense Data **************************************************/
        public static void ExpenseListSerializer(ExpenseEntity expense)
        {
            string path = @"C:\Users\Deepak\Desktop\notes\Work from home\DailyPersonalExpenseManagementSystem\DPEMS.DataAccess\DataBase\Expense.txt";
            BinaryFormatter formatter = new BinaryFormatter();
            try
            {


                if (File.Exists(path))
                {
                    expenses = ExpenseListDeSerializer();

                    expenses.Add(expense);
                    Stream stream = File.Open(path, FileMode.Open, FileAccess.Write);
                    formatter.Serialize(stream, expenses);
                    stream.Close();
                }
                else
                {
                    expenses.Add(expense);
                    Stream stream = File.Open(path, FileMode.Create, FileAccess.Write);
                    formatter.Serialize(stream, expenses);
                    stream.Close();
                }
            }
            catch (FileNotFoundException)
            {
                Console.WriteLine("File Not Exixt In Current Context!!:");
            }
            catch (Exception fileException)
            {
                Console.WriteLine(fileException.Message);
            }
        }


        /**********************Desirializ All Budget Data*****************************/
        public static List<BudgetEntity> BudgetListDeSerializer()
        {
            string path = @"C:\Users\Deepak\Desktop\notes\Work from home\DailyPersonalExpenseManagementSystem\DPEMS.DataAccess\DataBase\Budget.txt";
            BinaryFormatter formatter = new BinaryFormatter();

            Stream stream = File.Open(path, FileMode.Open, FileAccess.Read);
            List<BudgetEntity> budget = (List<BudgetEntity>)formatter.Deserialize(stream);
            stream.Close();
            return budget;
        }

        /**********************Desirializ All Expense Data*****************************/
        public static List<ExpenseEntity> ExpenseListDeSerializer()
        {
            string path = @"C:\Users\Deepak\Desktop\notes\Work from home\DailyPersonalExpenseManagementSystem\DPEMS.DataAccess\DataBase\Expense.txt";
            BinaryFormatter formatter = new BinaryFormatter();

            Stream stream = File.Open(path, FileMode.Open, FileAccess.Read);
            List<ExpenseEntity> expense = (List<ExpenseEntity>)formatter.Deserialize(stream);
            stream.Close();
            return expense;
        }
    }
}
