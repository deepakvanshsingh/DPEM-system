﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DPEMS.Entity;
using DPEMS.Exceptions;
using DPEMS.DataAccess;
namespace DPEMS.BusinessLogic
{
    public class DPEMS_BLL
    {
        /*****************Validating Budget Data**********************/
        public static bool CheckBudget(BudgetEntity budget)
        {
            if (budget.ExpenseHead.Length > 0 && budget.BudgetAmount > 0)
                return true;
            else
                return false;
        }

        /*****************Validating Expense Data**********************/
        public static bool CheckExpense(ExpenseEntity expense)
        {
            double totalItemExpanse = 0;
            double comapreAmount = 0;
            bool flag = false;
            StringBuilder errors = new StringBuilder();
            
            List<BudgetEntity> budget = DPEMS_BLL.GetBudget();
            List<ExpenseEntity> expenses = DPEMS_BLL.GetExpense();
            try { 
            foreach(BudgetEntity bgt in budget)
            {
                if (bgt.ExpenseHead.Equals(expense.ExpenseName))
                {
                    comapreAmount = bgt.BudgetAmount;
                }
            }

            foreach (ExpenseEntity exp in expenses)
            {
                if (exp.ExpenseName.Equals(expense.ExpenseName))
                {
                    totalItemExpanse += exp.ExpenseAmount;
                }
            }
           
                if ((expense.ExpenseAmount + totalItemExpanse) > 0 && (expense.ExpenseAmount + totalItemExpanse) <= comapreAmount)
                {

                    flag=true;
                }
                else
                {
                    flag = false;
                    throw (new DPEMS_Exceptions("Error: You are overspanding: " + ((expense.ExpenseAmount + totalItemExpanse) - comapreAmount) + "Rs"));
                }

                if(expense.ExpenseName.Length > 0 && expense.Day > 0 && expense.Day <= 31)
                {
                    flag = true;
                }
                else
                {
                    flag = false;
                    throw (new DPEMS_Exceptions("Error: Date should be (1 through 31)"));
                }
            }
            catch (DPEMS_Exceptions ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch(Exception ex)
            {
                Console.WriteLine(ex.Message);
            }

            return flag;
        }


        /*****************Calling to checkBudget than calling to DataAccess******************************/
        public static bool AddBudget(BudgetEntity budget)
        {
            if (CheckBudget(budget))
            {
                DPEMS_DAL.BudgetListSerializer(budget);
                return true;
            }
            else
            {
                return false;
            }

        }

        /*****************Calling to checkExpense than calling to DataAccess******************************/
        public static bool AddExpenseBLL(ExpenseEntity expense)
        {
            if (CheckExpense(expense))
            {
                DPEMS_DAL.ExpenseListSerializer(expense);
                return true;
            }
            else
            {
                return false;
            }

        }

        /********************Get All budgets Information******************/
        public static List<BudgetEntity> GetBudget()
        {
            return (DPEMS_DAL.BudgetListDeSerializer());
        }

        /********************Get All expenses Information******************/
        public static List<ExpenseEntity> GetExpense()
        {
            return (DPEMS_DAL.ExpenseListDeSerializer());
        }
    }
}
