﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DPEMS.Entity
{
    [Serializable]
    /****************Budget entity attribute***************/
   public class BudgetEntity
    {
        public string ExpenseHead { get; set; }
        public double BudgetAmount { get; set; }
    }
}
