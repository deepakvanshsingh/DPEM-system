﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DPEMS.Entity
{
    [Serializable]
    /****************Expense entity attribute***************/
    public class ExpenseEntity
    {
        public int Day { get; set; }
        public string ExpenseName { get; set; }
        public double ExpenseAmount { get; set; }
    }
}
