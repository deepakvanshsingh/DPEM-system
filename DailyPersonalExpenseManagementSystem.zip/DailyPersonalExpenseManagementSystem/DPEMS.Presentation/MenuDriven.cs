﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DPEMS.Entity;
using DPEMS.Exceptions;
using DPEMS.BusinessLogic;
namespace DPEMS.Presentation
{
    class MenuDriven
    {

        public static void Menu()
        {
            int choice = 1;
            int totalChoices;

            /**********************************Menu Driven for expence type**********************************/
            List<BudgetEntity> budgets = new List<BudgetEntity>();
            budgets = DPEMS_BLL.GetBudget();
            totalChoices = budgets.Count();
            foreach (BudgetEntity budget in budgets)
            {
                Console.WriteLine(choice + $": {budget.ExpenseHead}");
                choice++;
            }
            Console.WriteLine((choice)+": Exit");
            Console.WriteLine("Enter your choice:");
            choice = Convert.ToInt32(Console.ReadLine());
            if (choice <= totalChoices)
            {
                DPEMS_BLL.AddExpenseBLL(AddExpense(budgets[choice - 1]));
            }
            else if (choice == totalChoices + 1)
            {
                Environment.Exit(0);
            }
            else
            {
                Console.WriteLine("Wrong choice!! Please try again.");
                Console.ReadKey();
                Console.Clear();
                Menu();
            }

        }

        /******************adding expenses****************/
        public static ExpenseEntity AddExpense(BudgetEntity budget)
        { 
            ExpenseEntity expense = new ExpenseEntity();
            try
            {
                expense.ExpenseName = budget.ExpenseHead;
                Console.WriteLine("Enter Date (1 through 31):");
                expense.Day = Convert.ToInt32(Console.ReadLine());
                Console.WriteLine("Enter the expense amount:");
                expense.ExpenseAmount = Convert.ToDouble(Console.ReadLine());
               
            }
            catch (FormatException)
            {
                Console.WriteLine("ERROR: The enterd formate of data is not aproprite");
            }
            catch (Exception ex)
            {
                Console.WriteLine("ERROR: " + ex.Message);
            }
            return expense;
        }

        /******************Creating monthly budget*********************/
        public static BudgetEntity CreateBudget()
        {
            BudgetEntity budget = new BudgetEntity();
            try
            {
                Console.WriteLine("Enter the Expense Head:");
                budget.ExpenseHead = Console.ReadLine();
                Console.WriteLine("Enter the budget amount:");
                budget.BudgetAmount = Convert.ToInt32(Console.ReadLine());
            }
            catch (FormatException)
            {
                Console.WriteLine("ERROR: The enterd formate of data is not aproprite");
            }
            catch (Exception ex)
            {
                Console.WriteLine("ERROR: " + ex.Message);
            }
            return budget;
        }
        /******************View budget*********************/
        public static void ViewBudget()
        {
            int count = 1;
            List<BudgetEntity> budgets = new List<BudgetEntity>();
            budgets = DPEMS_BLL.GetBudget();
            Console.WriteLine("*****************Details about budget******************");
            Console.WriteLine("Sr.No. |  Expense_Head    |     Budget_Amount");
            foreach (BudgetEntity budget in budgets)
            {
                Console.WriteLine(count+"      |  "+budget.ExpenseHead+"             "+budget.BudgetAmount);
                count++;
            }
            Console.WriteLine("*******************************************************");
        }

        /******************View expense*********************/
        public static void ViewExpense()
        {
            int count = 1;
            List<ExpenseEntity> expenses = new List<ExpenseEntity>();
            expenses = DPEMS_BLL.GetExpense();
            Console.WriteLine("*****************Report about Expenses**********************");
            Console.WriteLine("Sr.No. |  Date    |    Expense_Name    |     Expense_Amount");
            foreach (ExpenseEntity expense in expenses)
            {
                Console.WriteLine(count + "      |  " + expense.Day + "       |      " + expense.ExpenseName+"     |     "+expense.ExpenseAmount);
                count++;
            }
            Console.WriteLine("************************************************************");
           
        }
    }
}
