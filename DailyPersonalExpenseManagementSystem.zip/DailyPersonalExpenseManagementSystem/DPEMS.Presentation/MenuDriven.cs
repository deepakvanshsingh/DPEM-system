﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DPEMS.Entity;
using DPEMS.Exceptions;
using DPEMS.BusinessLogic;
namespace DPEMS.Presentation
{
    class MenuDriven
    {

        public static void Menu()
        {
            int choice = 1;
            int totalChoices=0;

            /**********************************Menu Driven for expense type**********************************/
            List<BudgetEntity> budgets = new List<BudgetEntity>();
            budgets = DPEMS_BLL.GetBudget();

           
      try {
                if (budgets != null)
                {
                    totalChoices = budgets.ToList().Count();
                    foreach (BudgetEntity budget in budgets)
                    {
                        Console.WriteLine(choice + $": {budget.ExpenseHead}");
                        choice++;
                    }
                    Console.WriteLine((choice) + ": Exit");
                    Console.WriteLine("Enter your choice:");
                    choice = Convert.ToInt32(Console.ReadLine());
                    if (choice <= totalChoices)
                    {
                        DPEMS_BLL.AddExpenseBLL(AddExpense(budgets[choice - 1]));
                    }
                    else if (choice == totalChoices + 1)
                    {
                       Console.Clear();
                       ExpenseManager.Main();
                    }
                    else
                    {
                        Console.WriteLine("Wrong choice!! Please try again.");
                        Console.ReadKey();
                        Console.Clear();
                        Menu();
                    }

                }
                else
                {
                    throw (new DPEMS_Exceptions("Error: First you have to create your budgets !!"));
                }
         
        }
            catch (DPEMS_Exceptions ex)
            {
                Console.WriteLine(ex.Message);
                Console.ReadKey();
                Console.Clear();
                ExpenseManager.Main();
            }
            catch (FormatException)
            {
                Console.WriteLine("Error: The enterd formate of data is not aproprite");
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error: "+ex.Message);
                Console.ReadKey();
            }

        }

        /******************adding expenses****************/
        public static ExpenseEntity AddExpense(BudgetEntity budget)
        { 
            ExpenseEntity expense = new ExpenseEntity();
            try
            {
                expense.ExpenseName = budget.ExpenseHead;
                Console.WriteLine("Enter Date (1 through 31):");
                expense.Day = Convert.ToInt32(Console.ReadLine());
                Console.WriteLine("Enter the expense amount:");
                expense.ExpenseAmount = Convert.ToDouble(Console.ReadLine());
               
            }
            catch (FormatException)
            {
                Console.WriteLine("ERROR: The enterd formate of data is not aproprite");
            }
            catch (Exception ex)
            {
                Console.WriteLine("ERROR: " + ex.Message);
            }
            return expense;
        }

        /******************Creating monthly budget*********************/
        public static BudgetEntity CreateBudget()
        {
            BudgetEntity budget = new BudgetEntity();
            try
            {
                Console.WriteLine("Enter the Expense Head:");
                budget.ExpenseHead = Console.ReadLine();
                Console.WriteLine("Enter the budget amount:");
                budget.BudgetAmount = Convert.ToInt32(Console.ReadLine());
            }
            catch (FormatException)
            {
                Console.WriteLine("ERROR: The enterd formate of data is not aproprite");
            }
            catch (Exception ex)
            {
                Console.WriteLine("ERROR: " + ex.Message);
            }
            return budget;
        }
        /******************View budget*********************/
        public static void ViewBudget()
        {
            int count = 1;
            List<BudgetEntity> budgets = new List<BudgetEntity>();
            budgets = DPEMS_BLL.GetBudget();
            try
            {
                if (budgets != null)
                {
                    Console.ForegroundColor = ConsoleColor.Green;
                    Console.WriteLine("*****************Details about budget******************");
                    Console.WriteLine("Sr.No. |  Expense_Head    |     Budget_Amount");
                    Console.WriteLine("*******************************************************");
                    Console.ForegroundColor = ConsoleColor.White;
                    foreach (BudgetEntity budget in budgets)
                    {
                        Console.WriteLine(count + "      |  " + budget.ExpenseHead + "             " + budget.BudgetAmount);
                        count++;
                    }
                    Console.ForegroundColor = ConsoleColor.Green;
                    Console.WriteLine("*******************************************************");
                    Console.ForegroundColor = ConsoleColor.White;
                }
                else
                {
                    throw (new DPEMS_Exceptions("Error: First you have to create your budgets !!"));
                }
            }
            catch (DPEMS_Exceptions ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (Exception ex) { Console.WriteLine(ex.Message); }


        }

        /******************View expense*********************/
        public static void ViewExpense()
        {
            int count = 1;
            double totalExpense = 0;
            List<ExpenseEntity> expenses = new List<ExpenseEntity>();
            expenses = DPEMS_BLL.GetExpense();
            try
            {
                Console.ForegroundColor = ConsoleColor.Green;
                if (expenses != null)
                {
                    Console.WriteLine("*****************Report about Expenses**********************");
                    Console.WriteLine("Sr.No. |  Date    |    Expense_Name    |     Expense_Amount");
                    Console.WriteLine("************************************************************");
                    Console.ForegroundColor = ConsoleColor.White;
                    foreach (ExpenseEntity expense in expenses)
                    {
                        Console.WriteLine(count + "      |  " + expense.Day + "       |      " + expense.ExpenseName + "     |     " + expense.ExpenseAmount);
                        count++;
                        totalExpense += expense.ExpenseAmount;
                    }
                    Console.ForegroundColor = ConsoleColor.Green;
                    Console.WriteLine("************************************************************");
                    Console.ForegroundColor = ConsoleColor.White;
                    Console.BackgroundColor = ConsoleColor.Blue;
                    Console.WriteLine($"                                    TATOAL EXPENSE: {totalExpense} Rs.");
                    Console.BackgroundColor = ConsoleColor.Black;
                    Console.ForegroundColor = ConsoleColor.Green;
                    Console.WriteLine("************************************************************");
                    Console.ForegroundColor = ConsoleColor.White;

                }
                else
                {
                    throw (new DPEMS_Exceptions("You didn't expense yet!!"));
                }
            }
            catch (DPEMS_Exceptions ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (Exception ex) { Console.WriteLine(ex.Message); }
                  
        }

        public static void AboutDeveloper()
        {
            
            Console.BackgroundColor = ConsoleColor.Blue;
            Console.WriteLine("************************************************************");
            Console.WriteLine("****************About Application Developer*****************");
            Console.WriteLine("************************************************************");
            Console.ForegroundColor = ConsoleColor.Red;
            Console.BackgroundColor = ConsoleColor.White;
            Console.WriteLine("Project:          DPEMS System                             .");
            Console.WriteLine("Name:             Deepak Singh                             .");
            Console.WriteLine("Job:        Software Associate                             .");
            Console.WriteLine("Company:   Capgemini Ltd.,Pvt.                             .");
            Console.ForegroundColor = ConsoleColor.White;
            Console.BackgroundColor = ConsoleColor.Blue;
            Console.WriteLine("************************************************************");
            Console.ForegroundColor = ConsoleColor.White;
            Console.BackgroundColor = ConsoleColor.Black;
        }
    }
}
