﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DPEMS.Entity;
using DPEMS.Exceptions;
using DPEMS.BusinessLogic;
namespace DPEMS.Presentation
{
    class ExpenseManager
    {
       public static void Main()
        {
            try
            {
            int choice = 0;
            do
                {
                    Console.ForegroundColor = ConsoleColor.Green;
                    Console.WriteLine("***********************************************************");
                    Console.WriteLine("            Daily Personal Expense Management System       ");
                    Console.WriteLine("************************************************************");
                    Console.ForegroundColor = ConsoleColor.White;
                    Console.WriteLine("1: Create Budget:");
                Console.WriteLine("2: View Budget");
                Console.WriteLine("3: Add Expense");
                Console.WriteLine("4: View Expense");
                Console.WriteLine("5: About");
                Console.WriteLine("6: Exit");
                    Console.WriteLine("Enter your choice:");
                choice = Convert.ToInt32(Console.ReadLine());
                switch (choice)
                {
                    case 1:
                       DPEMS_BLL.AddBudget(MenuDriven.CreateBudget());
                        break;
                    case 2:
                        MenuDriven.ViewBudget();
                        break;
                    case 3:
                        MenuDriven.Menu();
                        break;
                    case 4:
                        MenuDriven.ViewExpense();
                        break;
                    case 5:
                            MenuDriven.AboutDeveloper();
                        break;
                    case 6:
                        Environment.Exit(0);
                        break;
                    default:
                        Console.WriteLine("Wrong choice!! try again");
                        break;
                }
                Console.Write("Press any key for continue!!...");
                Console.ReadKey();
                Console.Clear();
            } while (choice != 6);
            }
            catch (FormatException) { Console.WriteLine("Error: The enterd formate of data is not aproprite");
                Console.ReadKey();
                Console.Clear();
                Main();}
            catch (Exception ex){
                Console.WriteLine("Error: "+ex.Message);
               }
           

        }
    }
}
